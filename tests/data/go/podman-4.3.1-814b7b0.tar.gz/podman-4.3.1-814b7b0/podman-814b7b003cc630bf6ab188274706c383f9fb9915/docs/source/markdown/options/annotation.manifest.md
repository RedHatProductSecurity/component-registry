#### **--annotation**=*annotation=value*

Set an annotation on the entry for the image.

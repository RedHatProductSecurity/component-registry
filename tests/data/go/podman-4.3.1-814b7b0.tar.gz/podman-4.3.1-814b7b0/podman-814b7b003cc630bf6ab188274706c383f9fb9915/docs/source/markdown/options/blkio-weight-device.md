#### **--blkio-weight-device**=*device:weight*

Block IO relative device weight.

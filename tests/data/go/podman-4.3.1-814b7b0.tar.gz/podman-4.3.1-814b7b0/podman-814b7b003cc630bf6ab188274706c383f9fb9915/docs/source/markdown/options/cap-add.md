#### **--cap-add**=*capability*

Add Linux capabilities.

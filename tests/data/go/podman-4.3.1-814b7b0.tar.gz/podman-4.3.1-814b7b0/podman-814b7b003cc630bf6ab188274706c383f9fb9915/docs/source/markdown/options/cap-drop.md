#### **--cap-drop**=*capability*

Drop Linux capabilities.

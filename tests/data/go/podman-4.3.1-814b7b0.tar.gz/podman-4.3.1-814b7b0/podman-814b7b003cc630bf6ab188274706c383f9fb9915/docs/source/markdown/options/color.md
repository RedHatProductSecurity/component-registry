#### **--color**

Output the containers with different colors in the log.

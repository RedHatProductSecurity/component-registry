#### **--creds**=*[username[:password]]*

The [username[:password]] to use to authenticate with the registry, if required.
If one or both values are not supplied, a command line prompt will appear and the
value can be entered. The password is entered without echo.

#### **--digestfile**=*Digestfile*

After copying the image, write the digest of the resulting image to the file.
(This option is not available with the remote Podman client, including Mac and Windows (excluding WSL2) machines)

#### **--dns-search**=*domain*

Set custom DNS search domains. Invalid if using **--dns-search** with **--network** that is set to **none** or **container:**_id_.
Use **--dns-search=.** if you don't wish to set the search domain.

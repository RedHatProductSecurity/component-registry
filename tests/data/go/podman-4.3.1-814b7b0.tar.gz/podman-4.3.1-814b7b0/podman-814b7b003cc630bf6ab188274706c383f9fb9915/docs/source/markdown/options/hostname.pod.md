#### **--hostname**=*name*

Set a hostname to the pod.

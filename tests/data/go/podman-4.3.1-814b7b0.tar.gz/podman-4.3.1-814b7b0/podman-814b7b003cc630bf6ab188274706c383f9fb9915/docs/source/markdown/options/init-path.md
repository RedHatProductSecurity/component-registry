#### **--init-path**=*path*

Path to the container-init binary.

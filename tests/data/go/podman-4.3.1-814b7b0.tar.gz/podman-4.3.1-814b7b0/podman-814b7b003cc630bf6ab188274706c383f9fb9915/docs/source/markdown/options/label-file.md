#### **--label-file**=*file*

Read in a line-delimited file of labels.

#### **--pod-id-file**=*file*

Read pod ID from the specified *file* and <<subcommand>> the pod. Can be specified multiple times.

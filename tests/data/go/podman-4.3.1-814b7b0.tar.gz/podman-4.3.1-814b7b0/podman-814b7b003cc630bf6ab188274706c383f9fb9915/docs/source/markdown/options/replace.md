#### **--replace**

If another <<container|pod>> with the same name already exists, replace and remove it. The default is **false**.

#### **--signal**, **-s**=**signal**

Signal to send to the container<<|s in the pod>>. For more information on Linux signals, refer to *signal(7)*.
The default is **SIGKILL**.

#### **--stop-signal**=*signal*

Signal to stop a container. Default is **SIGTERM**.

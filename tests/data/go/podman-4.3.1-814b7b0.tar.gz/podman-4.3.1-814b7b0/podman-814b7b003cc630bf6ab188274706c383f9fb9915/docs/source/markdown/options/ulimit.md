#### **--ulimit**=*option*

Ulimit options. You can use **host** to copy the current configuration from the host.

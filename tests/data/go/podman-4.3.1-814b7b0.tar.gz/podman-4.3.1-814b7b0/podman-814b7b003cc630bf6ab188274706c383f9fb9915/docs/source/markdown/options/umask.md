#### **--umask**=*umask*

Set the umask inside the container. Defaults to `0022`.
Remote connections use local containers.conf for defaults

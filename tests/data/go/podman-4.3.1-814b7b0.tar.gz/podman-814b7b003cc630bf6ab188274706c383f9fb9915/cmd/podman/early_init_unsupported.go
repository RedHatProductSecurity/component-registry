//go:build !linux
// +build !linux

package main

func earlyInitHook() {
}

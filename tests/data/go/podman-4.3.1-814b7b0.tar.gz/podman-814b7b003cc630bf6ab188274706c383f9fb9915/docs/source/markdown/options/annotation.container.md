#### **--annotation**=*key=value*

Add an annotation to the container<<| or pod>>. This option can be set multiple times.

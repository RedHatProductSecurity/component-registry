#### **--cidfile**=*file*

Read container ID from the specified *file* and <<subcommand>> the container.
Can be specified multiple times.

#### **--cidfile**=*file*

Write the container ID to *file*.

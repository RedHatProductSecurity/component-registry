#### **--destroy**

Remove the original <<container|pod>> that we are cloning once used to mimic the configuration.

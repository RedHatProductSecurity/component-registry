#### **--features**

Specify the features list which the list or index records as requirements for
the image.  This option is rarely used.

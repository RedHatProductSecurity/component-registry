#### **--infra-command**=*command*

The command that will be run to start the infra container. Default: "/pause".

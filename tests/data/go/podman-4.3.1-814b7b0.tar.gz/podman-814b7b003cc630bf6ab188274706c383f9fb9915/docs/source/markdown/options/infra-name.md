#### **--infra-name**=*name*

The name that will be used for the pod's infra container.

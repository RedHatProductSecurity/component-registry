#### **--interactive**, **-i**

When set to **true**, keep stdin open even if not attached. The default is **false**.

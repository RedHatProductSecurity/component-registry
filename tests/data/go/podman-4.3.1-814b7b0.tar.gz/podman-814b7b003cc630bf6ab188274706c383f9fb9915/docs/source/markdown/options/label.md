#### **--label**, **-l**=*key=value*

Add metadata to a <<container|pod>>.

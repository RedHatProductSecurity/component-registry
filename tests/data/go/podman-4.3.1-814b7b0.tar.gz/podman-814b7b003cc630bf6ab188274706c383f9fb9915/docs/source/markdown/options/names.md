#### **--names**, **-n**

Output the container names instead of the container IDs in the log.

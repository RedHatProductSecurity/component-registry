#### **--no-reset**

Do not clear the terminal/screen in between reporting intervals

#### **--no-stream**

Disable streaming <<|pod >>stats and only pull the first result, default setting is false

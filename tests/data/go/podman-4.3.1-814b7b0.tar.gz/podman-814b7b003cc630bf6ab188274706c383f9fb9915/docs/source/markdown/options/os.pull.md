#### **--os**=*OS*

Override the OS, defaults to hosts, of the image to be pulled. For example, `windows`.
Unless overridden, subsequent lookups of the same image in the local storage will match this OS, regardless of the host.

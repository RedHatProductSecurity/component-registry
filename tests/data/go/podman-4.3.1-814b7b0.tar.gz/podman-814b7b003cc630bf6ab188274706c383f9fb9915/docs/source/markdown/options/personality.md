#### **--personality**=*persona*

Personality sets the execution domain via Linux personality(2).

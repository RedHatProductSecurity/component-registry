#### **--stop-timeout**=*seconds*

Timeout to stop a container. Default is **10**.
Remote connections use local containers.conf for defaults

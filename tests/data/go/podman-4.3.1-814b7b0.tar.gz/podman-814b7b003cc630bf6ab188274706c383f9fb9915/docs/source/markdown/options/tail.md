#### **--tail**=*LINES*

Output the specified number of LINES at the end of the logs.  LINES must be an integer.  Defaults to -1,
which prints all lines

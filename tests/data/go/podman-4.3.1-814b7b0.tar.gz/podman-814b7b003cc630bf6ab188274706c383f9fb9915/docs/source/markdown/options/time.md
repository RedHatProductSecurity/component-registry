#### **--time**, **-t**=*seconds*

Seconds to wait before forcibly stopping <<the container|running containers within the pod>>.

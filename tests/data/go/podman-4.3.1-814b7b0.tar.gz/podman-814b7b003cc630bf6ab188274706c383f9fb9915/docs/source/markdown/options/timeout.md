#### **--timeout**=*seconds*

Maximum time a container is allowed to run before conmon sends it the kill
signal.  By default containers will run until they exit or are stopped by
`podman stop`.

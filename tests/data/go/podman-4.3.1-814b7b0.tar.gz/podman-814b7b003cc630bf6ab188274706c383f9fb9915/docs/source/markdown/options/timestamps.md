#### **--timestamps**, **-t**

Show timestamps in the log outputs.  The default is false

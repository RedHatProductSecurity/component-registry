// Package storage provides helper functions for creating and managing CRI pod
// sandboxes and containers and metadata associated with them in the format
// that crio understands.  The API it provides should be considered to be
// unstable.
package storage

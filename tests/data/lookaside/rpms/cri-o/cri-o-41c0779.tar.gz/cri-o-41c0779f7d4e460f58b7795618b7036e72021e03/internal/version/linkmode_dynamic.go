//go:build !static
// +build !static

package version

const linkmode = "dynamic"

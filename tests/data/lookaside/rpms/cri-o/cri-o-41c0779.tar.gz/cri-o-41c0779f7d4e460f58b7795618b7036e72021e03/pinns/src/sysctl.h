#pragma once
#if !defined(SYSCTL_H)
#define SYSCTL_H

int configure_sysctls (char ** const sysctls, int size);

#endif // SYSCTL_H

#!/usr/bin/env sh
echo "$@" >>HOOKSCHECK
read -r line
echo "$line" >>HOOKSCHECK

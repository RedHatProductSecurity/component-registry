package utils

const (
	PodCgroupName = "pod"
)
